﻿using MySql.Data.MySqlClient;
using QRCoder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PPE_Desktop
{
    public partial class recherche : Form
    {
        public recherche()
        {
            InitializeComponent();
        }
        List<String> idp = new List<String>();
        private void bt_recherche_Click(object sender, EventArgs e)
        {
            lb_sortie.Text = "";
            DBConnection dbCon = new DBConnection();
            dbCon.Server = "localhost";
            dbCon.DatabaseName = "ppe";
            dbCon.UserName = "root";
            dbCon.Password = "";
            if (dbCon.IsConnect())
            {
                int i = 0;
                String NomParticipant = tb_recherche.Text;

            String query = "select idu,nom,prenom,mail FROM participant where nom = ?nom";
            query = Tools.PrepareLigne(query, "?nom", Tools.PrepareChamp(NomParticipant, "Chaine"));
            var cmd = new MySqlCommand(query, dbCon.Connection);
            List<Participant> LesParticipantTrouves = new List<Participant>();
            MySqlDataReader TheReader = cmd.ExecuteReader();
            while (TheReader.Read())
            {

                Participant unParticipant = new Participant
                {
                    ParticipantID = (int)TheReader["idu"],
                    ParticipantNom = (string)TheReader["nom"],
                    ParticipantPrenom = (string)TheReader["prenom"],
                    ParticipantMail = (string)TheReader["mail"]
                };
                LesParticipantTrouves.Add(unParticipant);
            }
                if (LesParticipantTrouves.Count > 0)
                {
                    foreach (Participant leParticipant in LesParticipantTrouves)
                    {
                        lb_sortie.Text += (" ID : " + leParticipant.ParticipantID + Environment.NewLine 
                                            + " nom : " + leParticipant.ParticipantNom + Environment.NewLine
                                            + " prenom : " + leParticipant.ParticipantPrenom + Environment.NewLine
                                            + " mail :" + leParticipant.ParticipantMail + Environment.NewLine);
                        i++;
                        cb_id.Items.Add(i + " " + leParticipant.ParticipantNom + " " + leParticipant.ParticipantPrenom);
                        idp.Add(leParticipant.ParticipantID.ToString());


                    }
                    cb_id.Visible = true;
                    bt_id.Visible = true;
                }
                else
                {
                    MessageBox.Show("pas de résutal");
                    TheReader.Close();
                    cb_id.Visible = false;
                    bt_id.Visible = false;
                    cb_id.Items.Clear();
                   }
            }
            else
            {
                MessageBox.Show("pas de connexion");
            }
            
        }

        private void bt_id_Click(object sender, EventArgs e)
        {
            DBConnection dbCon = new DBConnection();
            dbCon.Server = "localhost";
            dbCon.DatabaseName = "ppe";
            dbCon.UserName = "root";
            dbCon.Password = "";
            if (dbCon.IsConnect())
            {
                Char first_id = cb_id.ToString()[1];
                String NomParticipant = idp[(int)(first_id)];
                String query = "select nom,prenom,mail FROM participant where idu = ?nom";
                query = Tools.PrepareLigne(query, "?nom", Tools.PrepareChamp(NomParticipant, "Chaine"));
                var cmd = new MySqlCommand(query, dbCon.Connection);
                List<Participant> LesParticipantTrouves = new List<Participant>();
                MySqlDataReader TheReader = cmd.ExecuteReader();
                while (TheReader.Read())
                {

                    Participant unParticipant = new Participant
                    {
                        ParticipantNom = (string)TheReader["nom"],
                        ParticipantPrenom = (string)TheReader["prenom"],
                        ParticipantMail = (string)TheReader["mail"]
                    };
                    LesParticipantTrouves.Add(unParticipant);
                }
                if (LesParticipantTrouves.Count > 0)
                {
                    foreach (Participant leParticipant in LesParticipantTrouves)
                    {
                        lb_sortie.Text += (" nom : " + leParticipant.ParticipantNom + Environment.NewLine
                                            + " prenom : " + leParticipant.ParticipantPrenom + Environment.NewLine
                                            + " mail :" + leParticipant.ParticipantMail + Environment.NewLine);
                    }
                

                    QRCodeGenerator qrGenerator = new QRCodeGenerator();
                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(lb_sortie.Text, QRCodeGenerator.ECCLevel.Q);

                    Base64QRCode qrCode = new Base64QRCode(qrCodeData);
                    string qrCodeImageAsBase64 = qrCode.GetGraphic(20);

                    StreamWriter monStreamWriter = new StreamWriter(@"BadgeSalon.html");//Necessite using System.IO;

                    String strImage = "<img src = \"data:image/png;base64," + qrCodeImageAsBase64 + "\">";
                    monStreamWriter.WriteLine("<html>");
                    monStreamWriter.WriteLine("<body>");
                    string temptext = "<P>" + "Le contenue du QRcode" + "</P>";
                    monStreamWriter.WriteLine(temptext);
                    temptext = "<P>" + lb_sortie.Text + "</P>";
                    monStreamWriter.WriteLine(temptext);
                    monStreamWriter.WriteLine(strImage);    //Ecriture de l'image base 64 dans le fichier
                    monStreamWriter.WriteLine("</body>");
                    monStreamWriter.WriteLine("</html>");

                    // Fermeture du StreamWriter (Très important) 
                    monStreamWriter.Close();
                    lb_sortie.Text = "QRcode de id :" + cb_id.Text + " crée";
                }
                else
                {
                    MessageBox.Show("pas de résutal");
                    TheReader.Close();
                }
            }
            else
            {
                MessageBox.Show("pas de connexion à la base de données");
            }
        }
    }
}
